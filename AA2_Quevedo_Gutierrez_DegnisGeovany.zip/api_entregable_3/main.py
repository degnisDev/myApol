from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import sqlite3
import os

# Inicializamos FastAPI
app = FastAPI(title="API Rest MyApol - Universidad")

# 1. Definimos el Modelo de Datos (Pydantic)
# Hacemos los campos flexibles para evitar errores de validación si la DB real varía
class Dispositivo(BaseModel):
    id: Optional[int] = None
    nombre: str
    id_marca: int
    id_categoria: int
    precio: float
    stock: Optional[int] = 0 
    url_imagen: Optional[str] = ""
    descripcion: Optional[str] = ""

# Función auxiliar para conectar a la base de datos
def get_db_connection():
    # RUTA PORTÁTIL: Busca el archivo database.db en la misma carpeta donde está este script
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    db_path = os.path.join(BASE_DIR, 'database.db')
    
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

# --- RUTAS DE LA API ---

@app.get("/dispositivos", response_model=List[Dispositivo])
def get_dispositivos():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM dispositivos")
    rows = cursor.fetchall()
    conn.close()
    
    productos = []
    for row in rows:
        d = dict(row)
        # Manejamos el caso de que 'stock' no esté en la tabla
        if 'stock' not in d:
            d['stock'] = 0
        productos.append(d)
        
    return productos

@app.post("/dispositivos", status_code=201)
def create_dispositivo(item: Dispositivo):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        query = """INSERT INTO dispositivos (nombre, id_marca, id_categoria, precio, url_imagen, descripcion) 
                   VALUES (?, ?, ?, ?, ?, ?)"""
        cursor.execute(query, (item.nombre, item.id_marca, item.id_categoria, item.precio, item.url_imagen, item.descripcion))
        conn.commit()
        return {"mensaje": "Dispositivo creado con éxito"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    finally:
        conn.close()

@app.put("/dispositivos/{id_dispositivo}")
def update_dispositivo(id_dispositivo: int, item: Dispositivo):
    conn = get_db_connection()
    cursor = conn.cursor()
    query = """UPDATE dispositivos SET nombre=?, id_marca=?, id_categoria=?, precio=?, url_imagen=?, descripcion=? 
               WHERE id=?"""
    cursor.execute(query, (item.nombre, item.id_marca, item.id_categoria, item.precio, item.url_imagen, item.descripcion, id_dispositivo))
    conn.commit()
    updated = cursor.rowcount
    conn.close()
    
    if updated == 0:
        raise HTTPException(status_code=404, detail="Dispositivo no encontrado")
    return {"mensaje": "Dispositivo actualizado con éxito"}

@app.delete("/dispositivos/{id_dispositivo}")
def delete_dispositivo(id_dispositivo: int):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM dispositivos WHERE id=?", (id_dispositivo,))
    conn.commit()
    deleted = cursor.rowcount
    conn.close()
    
    if deleted == 0:
        raise HTTPException(status_code=404, detail="Dispositivo no encontrado")
    return {"mensaje": "Dispositivo eliminado con éxito"}
